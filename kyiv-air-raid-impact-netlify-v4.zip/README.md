# Kyiv Air-Raid Impact — Netlify prototype v4

A no-build static dashboard designed for direct deployment to Netlify.

## Deploy

1. Unzip the package.
2. In Netlify open **Add new site → Deploy manually**.
3. Drag the unzipped folder into the upload area.
4. Netlify publishes `index.html` and applies the proxy rules from `netlify.toml` and `_redirects`.

No npm installation or build command is required.

## Changes in v4

- Replaced native `input[type=date]` controls with a fully custom date-range calendar that matches the dashboard design.
- Added a responsive modal on desktop and bottom sheet on mobile.
- Added range highlighting, start/end markers, month navigation, weekend/holiday colours, quick presets and complete-day validation.
- Mobile alert bars are now neutral `<span>` elements, not browser-native buttons.
- Mobile alert bars have no border, outline, inset stroke or shadow; this removes Samsung/Android browser ShapeOutline rendering.
- Added versioned CSS and JavaScript filenames plus Netlify cache headers so an older deployment cannot keep stale styles.
- Weekend and Ukrainian statutory holiday markers remain available throughout the timeline and date picker.

## Data flow

- The browser requests `/api/alerts`.
- Netlify proxies the request to `https://kyiv.digital/storage/air-alert/stats.html`.
- The page parses start/end events and recalculates durations from timestamps.
- If the live source is unavailable, the page uses a recent local cache; if no cache exists, it displays an embedded snapshot.
- The page refreshes automatically every five minutes and also has a manual refresh button.

## Baseline logic

- The user selects an inclusive start and end date in the custom range calendar.
- Only complete calendar days are selectable.
- Alerts per day are counted by the date on which each alert started.
- Total alert time and `09:00–18:00` overlap are calculated across every day in the selected period.
- Days with zero alerts remain in the denominator.
- The selected range is stored in the browser using `localStorage`.

## Methodology

- Time zone: Europe/Kyiv.
- Geography: Kyiv City, not Kyiv Oblast.
- Intervals crossing midnight are split between calendar days for daily duration totals.
- Daily alert count means alerts that started on that date.
- `09:00–18:00` means exact overlap with that time window.
- Ongoing alerts are measured up to the current Kyiv time.
- Durations are calculated from start/end timestamps rather than trusting the displayed duration field.

## Files

- `index.html` — semantic page structure
- `styles-v4.css` — responsive visual system and custom calendar
- `app-v4.js` — live data parser, analytics, date-range picker, calendar markers and timeline interactions
- `_redirects` / `netlify.toml` — Netlify data proxy
- `_headers` — cache control for reliable updates
