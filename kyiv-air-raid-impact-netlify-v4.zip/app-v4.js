(() => {
  'use strict';

  const SOURCE_URL = 'https://kyiv.digital/storage/air-alert/stats.html';
  const PROXY_URL = '/api/alerts';
  const CACHE_KEY = 'kyiv-alert-impact-cache-v1';
  const KYIV_TZ = 'Europe/Kyiv';
  const WORK_START = 9 * 60;
  const WORK_END = 18 * 60;
  const MINUTE = 60 * 1000;
  const DAY = 1440 * MINUTE;
  const BASELINE_RANGE_KEY = 'kyiv-alert-impact-baseline-range-v1';
  const DEFAULT_BASELINE_RANGE = { startMs: Date.UTC(2026, 7, 1), endMs: Date.UTC(2026, 7, 26) };
  const FALLBACK_COVERAGE_START = Date.UTC(2026, 7, 25);
  const FALLBACK_COVERAGE_END = Date.UTC(2026, 8, 3);

  const FIXED_UA_HOLIDAYS = new Map([
    ['01-01', "New Year's Day"],
    ['03-08', "International Women's Day"],
    ['05-01', 'Labour Day'],
    ['05-08', 'Remembrance and Victory Day'],
    ['06-28', 'Constitution Day'],
    ['07-15', 'Ukrainian Statehood Day'],
    ['08-24', 'Independence Day'],
    ['10-01', 'Defenders of Ukraine Day'],
    ['12-25', 'Christmas Day'],
  ]);

  const FALLBACK_BASELINE = {
    alertsPerDay: 2.42,
    totalMinutesPerDay: 114,
    workMinutesPerDay: 27,
    dayCount: 26,
    startMs: DEFAULT_BASELINE_RANGE.startMs,
    endMs: DEFAULT_BASELINE_RANGE.endMs,
    isEmbedded: true,
  };

  const FALLBACK_INTERVALS = [
    ['25.08.26 23:54','26.08.26 00:41'],
    ['26.08.26 20:55','26.08.26 21:28'],
    ['27.08.26 01:45','27.08.26 02:03'],['27.08.26 02:24','27.08.26 03:58'],['27.08.26 04:14','27.08.26 07:20'],['27.08.26 08:13','27.08.26 09:39'],['27.08.26 09:54','27.08.26 11:08'],['27.08.26 11:22','27.08.26 11:35'],['27.08.26 11:58','27.08.26 12:42'],['27.08.26 14:45','27.08.26 16:13'],['27.08.26 16:28','27.08.26 16:50'],['27.08.26 17:06','27.08.26 17:30'],['27.08.26 17:51','27.08.26 21:11'],['27.08.26 21:27','27.08.26 21:51'],['27.08.26 23:55','28.08.26 00:41'],
    ['28.08.26 02:27','28.08.26 02:39'],['28.08.26 03:32','28.08.26 03:46'],['28.08.26 03:49','28.08.26 04:00'],['28.08.26 05:05','28.08.26 07:18'],['28.08.26 08:04','28.08.26 08:46'],['28.08.26 09:17','28.08.26 09:36'],['28.08.26 10:05','28.08.26 10:27'],['28.08.26 10:56','28.08.26 11:41'],['28.08.26 14:17','28.08.26 14:47'],['28.08.26 16:45','28.08.26 19:09'],['28.08.26 20:04','28.08.26 21:08'],['28.08.26 22:25','28.08.26 23:28'],
    ['29.08.26 00:53','29.08.26 01:01'],['29.08.26 03:44','29.08.26 07:08'],['29.08.26 07:29','29.08.26 11:54'],['29.08.26 12:53','29.08.26 13:07'],['29.08.26 15:50','29.08.26 16:01'],['29.08.26 17:28','29.08.26 17:47'],['29.08.26 18:22','29.08.26 18:45'],['29.08.26 19:37','29.08.26 19:42'],['29.08.26 21:41','29.08.26 22:59'],['29.08.26 23:24','29.08.26 23:44'],
    ['30.08.26 00:14','30.08.26 00:41'],['30.08.26 04:51','30.08.26 05:32'],['30.08.26 08:42','30.08.26 10:04'],['30.08.26 11:13','30.08.26 11:24'],['30.08.26 12:22','30.08.26 13:45'],['30.08.26 14:21','30.08.26 14:37'],['30.08.26 15:03','30.08.26 15:36'],['30.08.26 15:54','30.08.26 16:52'],['30.08.26 18:19','30.08.26 19:31'],['30.08.26 20:29','30.08.26 22:10'],['30.08.26 22:44','30.08.26 22:56'],
    ['31.08.26 00:16','31.08.26 01:06'],['31.08.26 05:13','31.08.26 05:30'],['31.08.26 05:54','31.08.26 06:11'],['31.08.26 07:56','31.08.26 08:44'],['31.08.26 09:05','31.08.26 10:01'],['31.08.26 10:13','31.08.26 10:19'],['31.08.26 11:44','31.08.26 12:25'],['31.08.26 13:36','31.08.26 13:42'],['31.08.26 15:58','31.08.26 16:11'],['31.08.26 18:44','31.08.26 18:50'],['31.08.26 19:46','31.08.26 22:27'],['31.08.26 23:32','01.09.26 00:15'],
    ['01.09.26 02:10','01.09.26 03:21'],['01.09.26 09:49','01.09.26 10:35'],['01.09.26 15:50','01.09.26 15:54'],['01.09.26 17:37','01.09.26 18:07'],['01.09.26 18:23','01.09.26 19:21'],['01.09.26 19:32','01.09.26 20:21'],['01.09.26 20:43','01.09.26 21:44'],
    ['02.09.26 03:33','02.09.26 03:38'],['02.09.26 05:27','02.09.26 05:36'],['02.09.26 06:17','02.09.26 06:33'],['02.09.26 07:13','02.09.26 09:19'],['02.09.26 10:08','02.09.26 10:46'],['02.09.26 12:04','02.09.26 12:13'],['02.09.26 12:30','02.09.26 13:33'],['02.09.26 14:54','02.09.26 14:58'],['02.09.26 15:22','02.09.26 16:05'],['02.09.26 18:21','02.09.26 19:41'],['02.09.26 21:20','02.09.26 23:23'],
    ['03.09.26 00:03','03.09.26 00:46'],['03.09.26 03:18','03.09.26 03:54'],['03.09.26 05:23','03.09.26 07:23'],['03.09.26 08:12','03.09.26 09:32'],['03.09.26 10:58','03.09.26 14:20'],['03.09.26 15:40','03.09.26 16:46'],['03.09.26 18:56','03.09.26 23:12'],
    ['04.09.26 05:01','04.09.26 05:07']
  ];

  const state = {
    alerts: [],
    days: [],
    range: 10,
    selectedKey: null,
    sourceMode: 'loading',
    fetchedAt: null,
    baseline: FALLBACK_BASELINE,
    baselineRange: readBaselineRange(),
    baselineBounds: { minMs: DEFAULT_BASELINE_RANGE.startMs, maxMs: DEFAULT_BASELINE_RANGE.endMs },
    baselineDraftStartMs: null,
    baselineDraftEndMs: null,
    baselineCalendarMonthMs: Date.UTC(2026, 7, 1),
    baselineSelecting: 'start',
    baselineLastFocus: null,
  };

  const els = {};
  document.addEventListener('DOMContentLoaded', init);

  function init() {
    cacheElements();
    bindControls();
    loadData();
    window.setInterval(() => loadData({ silent: true }), 5 * 60 * 1000);
  }

  function cacheElements() {
    [
      'feedChip','feedLabel','updatedLabel','refreshButton','todayEyebrow','heroHeadline','heroSubline',
      'currentStatus','currentStatusText','kpiCount','kpiCountNote','kpiTotal','kpiWork','kpiLongest',
      'kpiLongestNote','baselineCount','baselineTotal','baselineWork','baselineInsight','baselineRangeLabel',
      'baselinePeriodMeta','baselineRangeTrigger','baselineModal','baselineClose','baselineCancel','baselineApply',
      'baselineDraftStart','baselineDraftEnd','baselineDraftDays','calendarPrev','calendarNext','calendarMonthLabel',
      'calendarGrid','timelineGrid','timelineScroll','mobileTimeline','workToggle','detailTitle','detailSummary',
      'detailPills','detailList','tooltip','toast'
    ].forEach(id => els[id] = document.getElementById(id));
  }

  function bindControls() {
    document.querySelectorAll('[data-range]').forEach(btn => {
      btn.addEventListener('click', () => {
        state.range = Number(btn.dataset.range);
        document.querySelectorAll('[data-range]').forEach(b => b.classList.toggle('is-active', b === btn));
        renderTimelines();
      });
    });

    els.workToggle.addEventListener('change', () => document.body.classList.toggle('hide-work', !els.workToggle.checked));
    els.refreshButton.addEventListener('click', () => loadData());
    els.baselineRangeTrigger.addEventListener('click', openBaselineModal);
    document.querySelectorAll('[data-baseline-close]').forEach(control => control.addEventListener('click', closeBaselineModal));
    els.baselineApply.addEventListener('click', commitBaselineRange);
    els.calendarPrev.addEventListener('click', () => shiftBaselineCalendar(-1));
    els.calendarNext.addEventListener('click', () => shiftBaselineCalendar(1));

    els.calendarGrid.addEventListener('click', event => {
      const button = event.target.closest('[data-calendar-date]');
      if (!button || button.disabled) return;
      selectBaselineDate(Number(button.dataset.calendarDate));
    });

    document.querySelectorAll('[data-baseline-preset]').forEach(button => {
      button.addEventListener('click', () => applyBaselinePreset(button.dataset.baselinePreset));
    });

    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && !els.baselineModal.hidden) closeBaselineModal();
    });
    window.addEventListener('resize', hideTooltip);
  }

  function openBaselineModal() {
    state.baselineLastFocus = document.activeElement;
    state.baselineDraftStartMs = state.baselineRange.startMs;
    state.baselineDraftEndMs = state.baselineRange.endMs;
    state.baselineCalendarMonthMs = monthStart(state.baselineRange.startMs);
    state.baselineSelecting = 'start';
    renderBaselinePicker();
    els.baselineModal.hidden = false;
    els.baselineRangeTrigger.setAttribute('aria-expanded', 'true');
    document.body.classList.add('modal-open');
    requestAnimationFrame(() => els.baselineClose.focus({ preventScroll: true }));
  }

  function closeBaselineModal() {
    if (els.baselineModal.hidden) return;
    els.baselineModal.hidden = true;
    els.baselineRangeTrigger.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('modal-open');
    state.baselineLastFocus?.focus?.({ preventScroll: true });
  }

  function applyBaselinePreset(preset) {
    const maxMs = state.baselineBounds.maxMs;
    let startMs;
    let endMs;
    if (preset === 'pre-spike') {
      ({ startMs, endMs } = DEFAULT_BASELINE_RANGE);
    } else if (preset === 'previous-7') {
      endMs = maxMs;
      startMs = endMs - 6 * DAY;
    } else {
      endMs = maxMs;
      startMs = endMs - 29 * DAY;
    }
    setBaselineDraftRange(startMs, endMs);
  }

  function setBaselineDraftRange(startMs, endMs) {
    const { minMs, maxMs } = state.baselineBounds;
    state.baselineDraftStartMs = Math.max(minMs, Math.min(startMs, maxMs));
    state.baselineDraftEndMs = Math.max(state.baselineDraftStartMs, Math.min(endMs, maxMs));
    state.baselineCalendarMonthMs = monthStart(state.baselineDraftStartMs);
    state.baselineSelecting = 'start';
    renderBaselinePicker();
  }

  function selectBaselineDate(dayMs) {
    if (dayMs < state.baselineBounds.minMs || dayMs > state.baselineBounds.maxMs) return;
    if (state.baselineSelecting === 'start') {
      state.baselineDraftStartMs = dayMs;
      state.baselineDraftEndMs = null;
      state.baselineSelecting = 'end';
    } else {
      if (dayMs < state.baselineDraftStartMs) {
        state.baselineDraftEndMs = state.baselineDraftStartMs;
        state.baselineDraftStartMs = dayMs;
      } else {
        state.baselineDraftEndMs = dayMs;
      }
      state.baselineSelecting = 'start';
    }
    renderBaselinePicker();
  }

  function shiftBaselineCalendar(delta) {
    const d = new Date(state.baselineCalendarMonthMs);
    const next = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + delta, 1);
    const minMonth = monthStart(state.baselineBounds.minMs);
    const maxMonth = monthStart(state.baselineBounds.maxMs);
    state.baselineCalendarMonthMs = Math.max(minMonth, Math.min(next, maxMonth));
    renderBaselinePicker();
  }

  function renderBaselinePicker() {
    const startMs = state.baselineDraftStartMs;
    const endMs = state.baselineDraftEndMs;
    els.baselineDraftStart.textContent = startMs == null ? 'Select date' : formatDateFull(startMs);
    els.baselineDraftEnd.textContent = endMs == null ? 'Select date' : formatDateFull(endMs);
    els.baselineDraftDays.textContent = endMs == null
      ? 'Now choose the end date'
      : `${Math.round((endMs - startMs) / DAY) + 1} complete ${endMs === startMs ? 'day' : 'days'}`;

    document.querySelectorAll('[data-baseline-preset]').forEach(button => {
      const preset = button.dataset.baselinePreset;
      let a;
      let b;
      if (preset === 'pre-spike') ({ startMs: a, endMs: b } = DEFAULT_BASELINE_RANGE);
      else if (preset === 'previous-7') { b = state.baselineBounds.maxMs; a = b - 6 * DAY; }
      else { b = state.baselineBounds.maxMs; a = b - 29 * DAY; }
      a = Math.max(state.baselineBounds.minMs, a);
      button.classList.toggle('is-active', startMs === a && endMs === b);
    });

    const monthMs = state.baselineCalendarMonthMs;
    els.calendarMonthLabel.textContent = formatMonthYear(monthMs);
    els.calendarPrev.disabled = monthMs <= monthStart(state.baselineBounds.minMs);
    els.calendarNext.disabled = monthMs >= monthStart(state.baselineBounds.maxMs);
    els.calendarGrid.innerHTML = '';

    const monthDate = new Date(monthMs);
    const mondayOffset = (monthDate.getUTCDay() + 6) % 7;
    const gridStart = monthMs - mondayOffset * DAY;
    for (let i = 0; i < 42; i += 1) {
      const dayMs = gridStart + i * DAY;
      const d = new Date(dayMs);
      const disabled = dayMs < state.baselineBounds.minMs || dayMs > state.baselineBounds.maxMs;
      const outside = d.getUTCMonth() !== monthDate.getUTCMonth();
      const selectedStart = dayMs === startMs;
      const selectedEnd = dayMs === endMs;
      const inRange = endMs != null && dayMs > startMs && dayMs < endMs;
      const weekend = d.getUTCDay() === 0 || d.getUTCDay() === 6;
      const holiday = ukrainianHoliday(dayMs);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'calendar-day';
      if (outside) button.classList.add('is-outside');
      if (inRange) button.classList.add('is-in-range');
      if (selectedStart) button.classList.add('is-start');
      if (selectedEnd) button.classList.add('is-end');
      if (weekend || holiday) button.classList.add('is-special');
      button.disabled = disabled;
      button.dataset.calendarDate = String(dayMs);
      button.setAttribute('role', 'gridcell');
      button.setAttribute('aria-selected', String(selectedStart || selectedEnd));
      button.setAttribute('aria-label', `${formatDateFull(dayMs)}${holiday ? `, ${holiday}` : ''}`);
      button.innerHTML = `<span>${d.getUTCDate()}</span>${holiday ? '<i aria-hidden="true"></i>' : ''}`;
      els.calendarGrid.appendChild(button);
    }
  }

  function commitBaselineRange() {
    const startMs = state.baselineDraftStartMs;
    const endMs = state.baselineDraftEndMs;
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) {
      showToast('Choose both baseline dates');
      return;
    }
    if (startMs > endMs) {
      showToast('The baseline start must be before the end');
      return;
    }
    if (endMs > state.baselineBounds.maxMs) {
      showToast('Use complete calendar days only');
      return;
    }
    const dayCount = Math.round((endMs - startMs) / DAY) + 1;
    if (dayCount > 366) {
      showToast('Choose a baseline period of 366 days or less');
      return;
    }
    if (state.sourceMode === 'fallback' && !fallbackCoversRange(startMs, endMs) && !isDefaultBaselineRange(startMs, endMs)) {
      showToast('Live data is needed for that baseline period');
      return;
    }
    state.baselineRange = { startMs, endMs };
    try { localStorage.setItem(BASELINE_RANGE_KEY, JSON.stringify(state.baselineRange)); } catch { /* storage may be unavailable */ }
    state.baseline = resolveBaseline();
    renderBaseline();
    closeBaselineModal();
    showToast(`Baseline updated · ${formatRangeLabel(startMs, endMs)}`);
  }

  async function loadData({ silent = false } = {}) {
    if (!silent) els.refreshButton.classList.add('is-loading');
    setFeedState('loading', 'Refreshing');

    let mode = 'live';
    let alerts;

    try {
      const html = await fetchSource();
      alerts = parseKyivDigital(html);
      if (alerts.length < 10) throw new Error('Parsed too few alerts');
      try { localStorage.setItem(CACHE_KEY, JSON.stringify({ alerts, fetchedAt: Date.now() })); } catch { /* storage may be unavailable */ }
    } catch (primaryError) {
      const cached = readCache();
      if (cached?.alerts?.length) {
        alerts = cached.alerts;
        state.fetchedAt = cached.fetchedAt;
        mode = 'cached';
      } else {
        alerts = buildFallbackAlerts();
        mode = 'fallback';
      }
    }

    state.alerts = alerts.map(normalizeSerializedAlert);
    state.fetchedAt = state.fetchedAt || Date.now();
    state.sourceMode = mode;
    state.days = buildDailyModel(state.alerts);
    setBaselineBounds();
    state.baseline = resolveBaseline();
    state.selectedKey = chooseSelectedKey();

    renderAll();
    setFeedState(mode, mode === 'live' ? 'Live data' : mode === 'cached' ? 'Cached data' : 'Demo snapshot');
    els.updatedLabel.textContent = `Refreshed ${formatClock(getKyivNow())}`;
    els.refreshButton.classList.remove('is-loading');
    if (!silent) showToast(mode === 'live' ? 'Data refreshed' : mode === 'cached' ? 'Using the last saved dataset' : 'Live feed unavailable — showing embedded snapshot');
  }

  async function fetchSource() {
    if (['localhost', '127.0.0.1'].includes(window.location.hostname)) {
      throw new Error('Local preview uses embedded snapshot');
    }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    const options = { cache: 'no-store', signal: controller.signal };
    try {
      let response = await fetch(`${PROXY_URL}?t=${Date.now()}`, options);
      if (!response.ok) response = await fetch(`${SOURCE_URL}?t=${Date.now()}`, options);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      state.fetchedAt = Date.now();
      return await response.text();
    } finally {
      clearTimeout(timeout);
    }
  }

  function parseKyivDigital(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const eventPattern = /(\d{2}:\d{2})\s+(\d{2}\.\d{2}\.\d{2}).*?(Повітряна тривога!?|Відбій тривоги)/u;
    const candidates = [...doc.body.querySelectorAll('*')].filter(el => {
      const text = normalizeText(el.textContent);
      if (!eventPattern.test(text)) return false;
      return ![...el.children].some(child => eventPattern.test(normalizeText(child.textContent)));
    });

    let events = candidates.map(el => parseEventText(normalizeText(el.textContent))).filter(Boolean);

    if (events.length < 10 && doc.body.innerText) {
      events = doc.body.innerText.split(/\n+/).map(normalizeText).map(parseEventText).filter(Boolean);
    }

    const unique = new Map();
    events.forEach(e => unique.set(`${e.ms}|${e.type}`, e));
    events = [...unique.values()].sort((a,b) => a.ms - b.ms);

    const alerts = [];
    let open = null;
    for (const event of events) {
      if (event.type === 'start') {
        open = event;
      } else if (open && event.ms >= open.ms) {
        alerts.push({ startMs: open.ms, endMs: event.ms, ongoing: false });
        open = null;
      }
    }

    if (open) {
      const now = getKyivNow();
      if (now > open.ms) alerts.push({ startMs: open.ms, endMs: now, ongoing: true });
    }
    return alerts;
  }

  function parseEventText(text) {
    const m = text.match(/(\d{2}:\d{2})\s+(\d{2}\.\d{2}\.\d{2}).*?(Повітряна тривога!?|Відбій тривоги)/u);
    if (!m) return null;
    return {
      ms: parseLocalDateTime(`${m[2]} ${m[1]}`),
      type: m[3].startsWith('Повітряна') ? 'start' : 'end',
    };
  }

  function normalizeText(value) { return String(value || '').replace(/\s+/g, ' ').trim(); }

  function buildFallbackAlerts() {
    return FALLBACK_INTERVALS.map(([start,end]) => ({ startMs: parseLocalDateTime(start), endMs: parseLocalDateTime(end), ongoing: false }));
  }

  function normalizeSerializedAlert(a) {
    return { startMs: Number(a.startMs), endMs: Number(a.endMs), ongoing: Boolean(a.ongoing) };
  }

  function parseLocalDateTime(value) {
    const m = value.match(/(\d{2})\.(\d{2})\.(\d{2})\s+(\d{2}):(\d{2})/);
    if (!m) throw new Error(`Invalid date ${value}`);
    return Date.UTC(2000 + Number(m[3]), Number(m[2]) - 1, Number(m[1]), Number(m[4]), Number(m[5]));
  }

  function getKyivNow() {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: KYIV_TZ, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hourCycle:'h23'
    }).formatToParts(new Date());
    const p = Object.fromEntries(parts.filter(x => x.type !== 'literal').map(x => [x.type, x.value]));
    return Date.UTC(Number(p.year), Number(p.month)-1, Number(p.day), Number(p.hour), Number(p.minute));
  }

  function readCache() {
    try {
      const data = JSON.parse(localStorage.getItem(CACHE_KEY));
      if (!data || Date.now() - data.fetchedAt > 48 * 60 * 60 * 1000) return null;
      return data;
    } catch { return null; }
  }

  function readBaselineRange() {
    try {
      const saved = JSON.parse(localStorage.getItem(BASELINE_RANGE_KEY));
      const startMs = Number(saved?.startMs);
      const endMs = Number(saved?.endMs);
      if (Number.isFinite(startMs) && Number.isFinite(endMs) && startMs <= endMs) return { startMs, endMs };
    } catch { /* use default */ }
    return { ...DEFAULT_BASELINE_RANGE };
  }

  function setBaselineBounds() {
    const firstAlertDay = state.alerts.length ? dayStart(Math.min(...state.alerts.map(a => a.startMs))) : DEFAULT_BASELINE_RANGE.startMs;
    const earliestSelectableDay = state.sourceMode === 'fallback'
      ? Math.min(DEFAULT_BASELINE_RANGE.startMs, FALLBACK_COVERAGE_START)
      : firstAlertDay;
    const latestCompleteDay = dayStart(getKyivNow()) - DAY;
    state.baselineBounds = { minMs: earliestSelectableDay, maxMs: latestCompleteDay };

    const current = state.baselineRange;
    const valid = current.startMs >= earliestSelectableDay && current.endMs <= latestCompleteDay && current.startMs <= current.endMs;
    if (!valid) {
      const defaultFits = DEFAULT_BASELINE_RANGE.startMs >= earliestSelectableDay && DEFAULT_BASELINE_RANGE.endMs <= latestCompleteDay;
      state.baselineRange = defaultFits
        ? { ...DEFAULT_BASELINE_RANGE }
        : { startMs: Math.max(earliestSelectableDay, latestCompleteDay - 29 * DAY), endMs: latestCompleteDay };
    }
  }

  function monthStart(ms) {
    const d = new Date(ms);
    return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1);
  }

  function resolveBaseline() {
    const { startMs, endMs } = state.baselineRange;
    if (state.sourceMode === 'fallback' && isDefaultBaselineRange(startMs, endMs)) return { ...FALLBACK_BASELINE };
    if (state.sourceMode === 'fallback' && !fallbackCoversRange(startMs, endMs)) return { ...FALLBACK_BASELINE };
    return calculateBaseline(state.alerts, startMs, endMs);
  }

  function calculateBaseline(alerts, startMs, endMs) {
    const endExclusive = endMs + DAY;
    const dayCount = Math.round((endMs - startMs) / DAY) + 1;
    const started = alerts.filter(a => a.startMs >= startMs && a.startMs < endExclusive).length;
    let totalMinutes = 0;
    let workMinutes = 0;

    alerts.forEach(alert => {
      const overlapStart = Math.max(alert.startMs, startMs);
      const overlapEnd = Math.min(alert.endMs, endExclusive);
      if (overlapEnd <= overlapStart) return;
      totalMinutes += Math.round((overlapEnd - overlapStart) / MINUTE);

      for (let dayMs = dayStart(overlapStart); dayMs < overlapEnd; dayMs += DAY) {
        const windowStart = dayMs + WORK_START * MINUTE;
        const windowEnd = dayMs + WORK_END * MINUTE;
        workMinutes += Math.max(0, Math.round((Math.min(overlapEnd, windowEnd) - Math.max(overlapStart, windowStart)) / MINUTE));
      }
    });

    return {
      alertsPerDay: started / dayCount,
      totalMinutesPerDay: totalMinutes / dayCount,
      workMinutesPerDay: workMinutes / dayCount,
      dayCount,
      startMs,
      endMs,
      isEmbedded: false,
    };
  }

  function fallbackCoversRange(startMs, endMs) {
    return startMs >= FALLBACK_COVERAGE_START && endMs <= FALLBACK_COVERAGE_END;
  }

  function isDefaultBaselineRange(startMs, endMs) {
    return startMs === DEFAULT_BASELINE_RANGE.startMs && endMs === DEFAULT_BASELINE_RANGE.endMs;
  }

  function buildDailyModel(alerts) {
    const map = new Map();
    const ensure = dayMs => {
      const key = dateKey(dayMs);
      if (!map.has(key)) map.set(key, { key, dayMs, segments: [], starts: [], totalMinutes:0, workMinutes:0, longestMinutes:0, ongoing:false });
      return map.get(key);
    };

    alerts.forEach((alert, alertIndex) => {
      const startDay = dayStart(alert.startMs);
      ensure(startDay).starts.push(alert);
      let cursor = alert.startMs;
      let part = 0;
      while (cursor < alert.endMs) {
        const d0 = dayStart(cursor);
        const d1 = d0 + 1440 * MINUTE;
        const segEnd = Math.min(alert.endMs, d1);
        const startMinute = Math.round((cursor - d0) / MINUTE);
        const endMinute = Math.round((segEnd - d0) / MINUTE);
        const duration = Math.max(1, endMinute - startMinute);
        const work = overlapMinutes(startMinute, endMinute, WORK_START, WORK_END);
        const day = ensure(d0);
        day.segments.push({
          id: `${alertIndex}-${part}`,
          alertIndex,
          part,
          startMs: cursor,
          endMs: segEnd,
          originalStartMs: alert.startMs,
          originalEndMs: alert.endMs,
          startMinute,
          endMinute,
          durationMinutes: duration,
          workMinutes: work,
          ongoing: alert.ongoing && segEnd === alert.endMs,
          continuation: cursor !== alert.startMs,
        });
        day.totalMinutes += duration;
        day.workMinutes += work;
        day.longestMinutes = Math.max(day.longestMinutes, duration);
        day.ongoing ||= alert.ongoing;
        cursor = segEnd;
        part += 1;
      }
    });

    const nowDay = dayStart(getKyivNow());
    const minimumTimelineStart = nowDay - 30 * DAY;
    const firstAlertDay = map.size ? Math.min(...[...map.values()].map(d => d.dayMs)) : nowDay;
    const first = Math.min(firstAlertDay, minimumTimelineStart);
    for (let d = first; d <= nowDay; d += DAY) ensure(d);
    return [...map.values()].sort((a,b) => a.dayMs - b.dayMs);
  }

  function overlapMinutes(a0,a1,b0,b1) { return Math.max(0, Math.min(a1,b1) - Math.max(a0,b0)); }
  function dayStart(ms) { const d = new Date(ms); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()); }
  function dateKey(ms) { const d = new Date(ms); return `${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())}`; }
  function pad(n) { return String(n).padStart(2,'0'); }
  function inputDate(ms) { return dateKey(ms); }
  function parseInputDate(value) {
    const m = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : NaN;
  }

  function calendarMeta(ms) {
    const d = new Date(ms);
    const weekday = d.getUTCDay();
    const holiday = ukrainianHoliday(ms);
    return { weekend: weekday === 0 || weekday === 6, holiday };
  }

  function ukrainianHoliday(ms) {
    const d = new Date(ms);
    const year = d.getUTCFullYear();
    const key = `${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())}`;
    if (FIXED_UA_HOLIDAYS.has(key)) return FIXED_UA_HOLIDAYS.get(key);
    const easter = orthodoxEaster(year);
    if (dayStart(ms) === easter) return 'Easter';
    if (dayStart(ms) === easter + 49 * DAY) return 'Trinity Sunday';
    return null;
  }

  function orthodoxEaster(year) {
    const a = year % 4;
    const b = year % 7;
    const c = year % 19;
    const d = (19 * c + 15) % 30;
    const e = (2 * a + 4 * b - d + 34) % 7;
    const julianMonth = Math.floor((d + e + 114) / 31);
    const julianDay = ((d + e + 114) % 31) + 1;
    return Date.UTC(year, julianMonth - 1, julianDay) + 13 * DAY;
  }

  function formatDateFull(ms) {
    return new Intl.DateTimeFormat('en-GB', { day:'2-digit', month:'short', year:'numeric', timeZone:'UTC' }).format(new Date(ms));
  }

  function formatMonthYear(ms) {
    return new Intl.DateTimeFormat('en-GB', { month:'long', year:'numeric', timeZone:'UTC' }).format(new Date(ms));
  }

  function formatRangeLabel(startMs, endMs) {
    const start = new Date(startMs);
    const end = new Date(endMs);
    const sameYear = start.getUTCFullYear() === end.getUTCFullYear();
    const sameMonth = sameYear && start.getUTCMonth() === end.getUTCMonth();
    const startDay = start.getUTCDate();
    const endDay = end.getUTCDate();
    const startMonth = new Intl.DateTimeFormat('en-GB',{month:'short',timeZone:'UTC'}).format(start);
    const endMonth = new Intl.DateTimeFormat('en-GB',{month:'short',timeZone:'UTC'}).format(end);
    if (sameMonth) return `${startDay}–${endDay} ${endMonth} ${end.getUTCFullYear()}`;
    if (sameYear) return `${startDay} ${startMonth}–${endDay} ${endMonth} ${end.getUTCFullYear()}`;
    return `${startDay} ${startMonth} ${start.getUTCFullYear()}–${endDay} ${endMonth} ${end.getUTCFullYear()}`;
  }

  function chooseSelectedKey() {
    const today = dateKey(getKyivNow());
    return state.days.some(d => d.key === today) ? today : state.days.at(-1)?.key;
  }

  function renderAll() {
    renderHero();
    renderBaseline();
    renderTimelines();
    renderDetail();
  }

  function renderHero() {
    const now = getKyivNow();
    const today = state.days.find(d => d.key === dateKey(now)) || emptyDay(now);
    const active = state.alerts.find(a => a.ongoing);
    const dayLabel = formatDateLong(now).toUpperCase();
    els.todayEyebrow.textContent = `TODAY · ${dayLabel} · KYIV CITY`;

    els.heroHeadline.innerHTML = today.totalMinutes
      ? `Kyiv has spent <em>${formatDuration(today.totalMinutes)}</em> under air-raid alerts today.`
      : `No air-raid alert time has been recorded in Kyiv today.`;
    els.heroSubline.innerHTML = today.workMinutes
      ? `<strong>${formatDuration(today.workMinutes)}</strong> occurred inside the 09:00–18:00 window.`
      : `No alert time has overlapped the 09:00–18:00 window so far.`;

    els.kpiCount.textContent = today.starts.length;
    els.kpiCountNote.textContent = today.starts.length === 1 ? 'Alert started today' : 'Alerts started today';
    els.kpiTotal.textContent = formatDuration(today.totalMinutes);
    els.kpiWork.textContent = formatDuration(today.workMinutes);
    els.kpiLongest.textContent = formatDuration(today.longestMinutes);
    els.kpiLongestNote.textContent = today.longestMinutes ? 'Longest daily segment' : 'No alerts recorded';

    els.currentStatus.dataset.alert = active ? 'true' : 'false';
    els.currentStatusText.textContent = active
      ? `AIR-RAID ALERT ACTIVE · ${formatDuration(Math.round((now - active.startMs) / MINUTE))}`
      : 'NO ACTIVE AIR-RAID ALERT';
  }

  function renderBaseline() {
    const b = state.baseline;
    const { startMs, endMs } = state.baselineRange;
    els.baselineRangeLabel.textContent = formatRangeLabel(startMs, endMs);
    els.baselinePeriodMeta.textContent = `${b.dayCount} calendar ${b.dayCount === 1 ? 'day' : 'days'} · zero-alert days included${b.isEmbedded ? ' · embedded benchmark' : ''}`;
    els.baselineCount.textContent = b.alertsPerDay.toFixed(2);
    els.baselineTotal.textContent = formatDuration(Math.round(b.totalMinutesPerDay));
    els.baselineWork.textContent = formatDuration(Math.round(b.workMinutesPerDay));

    const complete = [...state.days].reverse().find(d => d.dayMs < dayStart(getKyivNow()) && d.starts.length);
    if (!complete) {
      els.baselineInsight.textContent = 'No completed alert day is available for comparison yet.';
      return;
    }
    if (!b.totalMinutesPerDay) {
      els.baselineInsight.textContent = 'The selected baseline period contains no recorded alert time.';
      return;
    }
    const ratio = complete.totalMinutes / b.totalMinutesPerDay;
    const direction = ratio >= 1 ? 'above' : 'below';
    els.baselineInsight.textContent = `${formatDateShort(complete.dayMs)} was ${ratio.toFixed(1)}× the selected average — ${direction} the chosen “usual” period.`;
  }

  function renderTimelines() {
    const shown = state.days.slice(-state.range);
    els.timelineGrid.innerHTML = '';
    els.mobileTimeline.innerHTML = '';
    shown.forEach(day => {
      els.timelineGrid.appendChild(createDesktopDay(day));
      els.mobileTimeline.appendChild(createMobileDay(day));
    });
    requestAnimationFrame(() => { els.timelineScroll.scrollLeft = els.timelineScroll.scrollWidth; });
  }

  function createDesktopDay(day) {
    const col = document.createElement('article');
    const meta = calendarMeta(day.dayMs);
    col.className = 'day-column';
    if (day.key === state.selectedKey) col.classList.add('is-selected');
    if (day.key === dateKey(getKyivNow())) col.classList.add('today-column');
    if (meta.weekend) col.classList.add('is-weekend');
    if (meta.holiday) col.classList.add('is-holiday');
    col.dataset.dayKey = day.key;
    col.innerHTML = `
      <header class="day-column-header">
        <span class="day-date">${formatDayMonth(day.dayMs)}</span>
        <span class="day-weekday-row">
          <span class="day-weekday">${formatWeekday(day.dayMs)}</span>
          ${meta.holiday ? `<span class="holiday-marker" title="${meta.holiday}" aria-label="${meta.holiday}">HOLIDAY</span>` : ''}
        </span>
        <div class="day-summary"><strong>${day.starts.length} ${day.starts.length === 1 ? 'alert' : 'alerts'}</strong><span>09–18 · ${formatCompact(day.workMinutes)}</span></div>
      </header>
      <div class="day-timeline"><span class="work-band"></span></div>`;
    const track = col.querySelector('.day-timeline');
    day.segments.forEach((seg, i) => track.appendChild(createAlertBlock(seg, i + 1, day)));
    col.addEventListener('click', e => {
      if (e.target.closest('.alert-block')) return;
      selectDay(day.key);
    });
    return col;
  }

  function createAlertBlock(seg, index, day) {
    const button = document.createElement('button');
    const top = seg.startMinute / 1440 * 100;
    const height = Math.max(seg.durationMinutes / 1440 * 100, .45);
    button.type = 'button';
    button.className = `alert-block${seg.ongoing ? ' is-ongoing' : ''}`;
    button.style.top = `${top}%`;
    button.style.height = `${height}%`;
    button.setAttribute('aria-label', tooltipPlain(seg, index));

    const before = Math.max(0, Math.min(seg.endMinute, WORK_START) - seg.startMinute);
    const work = seg.workMinutes;
    const after = Math.max(0, seg.durationMinutes - before - work);
    const parts = [
      ['alert-segment', before],
      ['alert-segment alert-work', work],
      ['alert-segment', after],
    ].filter(([,mins]) => mins > 0);
    let cursor = 0;
    parts.forEach(([cls,mins]) => {
      const span = document.createElement('span');
      span.className = cls;
      span.style.top = `${cursor / seg.durationMinutes * 100}%`;
      span.style.height = `${mins / seg.durationMinutes * 100}%`;
      button.appendChild(span);
      cursor += mins;
    });
    if (seg.durationMinutes >= 45) {
      const label = document.createElement('span');
      label.className = 'alert-label';
      label.textContent = formatCompact(seg.durationMinutes);
      button.appendChild(label);
    }

    button.addEventListener('mouseenter', e => showTooltip(e, seg, index));
    button.addEventListener('mousemove', positionTooltip);
    button.addEventListener('mouseleave', hideTooltip);
    button.addEventListener('focus', e => showTooltip(e, seg, index));
    button.addEventListener('blur', hideTooltip);
    button.addEventListener('click', e => { e.stopPropagation(); selectDay(day.key); });
    return button;
  }

  function createMobileDay(day) {
    const card = document.createElement('article');
    const meta = calendarMeta(day.dayMs);
    const specialWeekday = meta.weekend || meta.holiday;
    card.className = `mobile-day-card${day.key === state.selectedKey ? ' is-selected' : ''}${meta.weekend ? ' is-weekend' : ''}${meta.holiday ? ' is-holiday' : ''}`;
    card.dataset.dayKey = day.key;
    card.innerHTML = `
      <div class="mobile-day-head">
        <div class="mobile-day-title">
          <strong>${formatDayMonth(day.dayMs)} · <span class="mobile-weekday${specialWeekday ? ' is-special' : ''}">${formatWeekday(day.dayMs)}</span></strong>
          ${meta.holiday ? `<span class="mobile-holiday">${meta.holiday}</span>` : ''}
          <span class="mobile-total">${day.totalMinutes ? formatDuration(day.totalMinutes) + ' total' : 'No alert time'}</span>
        </div>
        <div class="mobile-day-stats"><strong>${day.starts.length} ${day.starts.length === 1 ? 'alert' : 'alerts'}</strong><span>09–18 · ${formatCompact(day.workMinutes)}</span></div>
      </div>
      <div class="mobile-track-wrap">
        <div class="mobile-track"><span class="mobile-work-band"></span></div>
        <div class="mobile-axis"><span>00:00</span><span>09:00</span><span>18:00</span><span>24:00</span></div>
      </div>`;
    const track = card.querySelector('.mobile-track');
    day.segments.forEach(seg => {
      const block = document.createElement('span');
      block.className = `mobile-alert-shape${seg.ongoing ? ' is-ongoing' : ''}`;
      block.style.left = `${seg.startMinute / 1440 * 100}%`;
      block.style.width = `${Math.max(seg.durationMinutes / 1440 * 100, .7)}%`;
      block.setAttribute('aria-hidden', 'true');
      if (seg.workMinutes) {
        const overlapStart = Math.max(seg.startMinute, WORK_START);
        const work = document.createElement('span');
        work.className = 'alert-work';
        work.style.left = `${(overlapStart - seg.startMinute) / seg.durationMinutes * 100}%`;
        work.style.width = `${seg.workMinutes / seg.durationMinutes * 100}%`;
        block.appendChild(work);
      }
      track.appendChild(block);
    });
    card.setAttribute('role', 'button');
    card.setAttribute('tabindex', '0');
    card.setAttribute('aria-label', `${formatDayMonth(day.dayMs)} ${formatWeekday(day.dayMs)}. ${day.starts.length} alerts. ${formatDuration(day.totalMinutes)} total.`);
    card.addEventListener('click', () => selectDay(day.key));
    card.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        selectDay(day.key);
      }
    });
    return card;
  }

  function selectDay(key) {
    state.selectedKey = key;
    document.querySelectorAll('[data-day-key]').forEach(el => el.classList.toggle('is-selected', el.dataset.dayKey === key));
    document.querySelectorAll('.mobile-day-card').forEach(el => {
      el.classList.toggle('is-selected', el.dataset.dayKey === key);
    });
    renderDetail();
    document.querySelector('.detail-section')?.scrollIntoView({ behavior:'smooth', block:'start' });
  }

  function renderDetail() {
    const day = state.days.find(d => d.key === state.selectedKey);
    if (!day) return;
    const meta = calendarMeta(day.dayMs);
    els.detailTitle.textContent = `${formatDayMonth(day.dayMs)} · ${formatWeekday(day.dayMs)}`;
    els.detailSummary.textContent = day.segments.length
      ? `${day.starts.length} ${day.starts.length === 1 ? 'alert started' : 'alerts started'} on this date. Every interval below uses recalculated start/end timestamps.`
      : 'No air-raid alert time was recorded for this date.';
    els.detailPills.innerHTML = `
      ${meta.holiday ? `<span class="detail-pill is-holiday">${meta.holiday}</span>` : ''}
      ${meta.weekend ? `<span class="detail-pill is-holiday">Weekend</span>` : ''}
      <span class="detail-pill">${formatDuration(day.totalMinutes)} total</span>
      <span class="detail-pill is-accent">${formatDuration(day.workMinutes)} in 09:00–18:00</span>
      <span class="detail-pill">${formatDuration(day.longestMinutes)} longest</span>`;

    if (!day.segments.length) {
      els.detailList.innerHTML = '<div class="empty-state">No alert intervals to display.</div>';
      return;
    }
    const max = Math.max(...day.segments.map(s => s.durationMinutes));
    els.detailList.innerHTML = '';
    day.segments.forEach((seg, i) => {
      const row = document.createElement('div');
      row.className = 'detail-row';
      row.innerHTML = `
        <span class="detail-index">#${String(i+1).padStart(2,'0')}</span>
        <span class="detail-time">${formatClock(seg.startMs)}–${seg.ongoing ? 'now' : formatClock(seg.endMs)}</span>
        <span class="detail-track"><span style="width:${seg.durationMinutes/max*100}%"></span></span>
        <strong class="detail-duration">${formatDuration(seg.durationMinutes)}</strong>
        <span class="detail-overlap">${seg.workMinutes ? formatDuration(seg.workMinutes) + ' in 09–18' : 'No 09–18 overlap'}</span>`;
      els.detailList.appendChild(row);
    });
  }

  function showTooltip(event, seg, index) {
    els.tooltip.innerHTML = `<strong>Alert #${String(index).padStart(2,'0')} · ${formatDuration(seg.durationMinutes)}</strong><span>${formatClock(seg.startMs)}–${seg.ongoing ? 'ongoing' : formatClock(seg.endMs)}${seg.continuation ? ' · continued after midnight' : ''}<br>${seg.workMinutes ? formatDuration(seg.workMinutes) + ' inside 09:00–18:00' : 'No overlap with 09:00–18:00'}</span>`;
    els.tooltip.hidden = false;
    positionTooltip(event);
  }

  function positionTooltip(event) {
    if (els.tooltip.hidden) return;
    const x = Math.min(window.innerWidth - 260, Math.max(12, event.clientX + 16));
    const y = Math.min(window.innerHeight - 120, Math.max(12, event.clientY + 16));
    els.tooltip.style.left = `${x}px`;
    els.tooltip.style.top = `${y}px`;
  }
  function hideTooltip() { els.tooltip.hidden = true; }

  function tooltipPlain(seg,index) {
    return `Alert ${index}, ${formatDuration(seg.durationMinutes)}, ${formatClock(seg.startMs)} to ${seg.ongoing ? 'ongoing' : formatClock(seg.endMs)}, ${formatDuration(seg.workMinutes)} within 09:00 to 18:00`;
  }

  function setFeedState(mode,label) {
    els.feedChip.dataset.state = mode;
    els.feedLabel.textContent = label;
  }

  let toastTimer;
  function showToast(message) {
    clearTimeout(toastTimer);
    els.toast.textContent = message;
    els.toast.classList.add('is-visible');
    toastTimer = setTimeout(() => els.toast.classList.remove('is-visible'), 2800);
  }

  function emptyDay(ms) { return { key:dateKey(ms), dayMs:dayStart(ms), segments:[], starts:[], totalMinutes:0, workMinutes:0, longestMinutes:0, ongoing:false }; }
  function formatDuration(mins) {
    const n = Math.max(0, Math.round(mins || 0));
    const h = Math.floor(n/60), m = n%60;
    if (!h) return `${m} min`;
    if (!m) return `${h} h`;
    return `${h} h ${m} min`;
  }
  function formatCompact(mins) {
    const n = Math.max(0, Math.round(mins || 0));
    return `${Math.floor(n/60)}h${String(n%60).padStart(2,'0')}`;
  }
  function formatClock(ms) { const d = new Date(ms); return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`; }
  function formatDayMonth(ms) { return new Intl.DateTimeFormat('en-GB',{day:'2-digit',month:'short',timeZone:'UTC'}).format(new Date(ms)); }
  function formatWeekday(ms) { return new Intl.DateTimeFormat('en-GB',{weekday:'short',timeZone:'UTC'}).format(new Date(ms)); }
  function formatDateShort(ms) { return new Intl.DateTimeFormat('en-GB',{day:'2-digit',month:'short',timeZone:'UTC'}).format(new Date(ms)); }
  function formatDateLong(ms) { return new Intl.DateTimeFormat('en-GB',{weekday:'short',day:'2-digit',month:'short',timeZone:'UTC'}).format(new Date(ms)); }
})();
