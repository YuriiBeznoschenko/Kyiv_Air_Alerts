# Kyiv Air-Raid Impact — Netlify prototype v6

Responsive, no-framework dashboard for Kyiv City air-raid alerts with live threat-level classification, historical context, a configurable baseline and a mobile-first timeline.

## What changed in v6

- Added live `Yellow` / `Red` threat classification when the configured API returns alert levels. The classified feed refreshes every minute; the heavier legacy history refreshes every five minutes.
- Yellow means a drone warning; red means a high-level air threat. History without a confirmed level remains blue-grey.
- An alert can contain several coloured phases when its level changes while the alert remains active.
- The `09:00–18:00` interval is now a background band, so it no longer replaces the threat colour.
- Added today's yellow, red and unclassified duration summary.
- Added threat labels and coloured phase bars to the selected-day detail view.
- On mobile, days are now ordered **newest first**: today appears at the top, followed by previous days.
- Desktop remains chronological from left to right.
- Kept the custom baseline date picker, weekend / Ukrainian holiday markers and the Netlify-badge-safe mobile modal layout.

## Secure API setup

The browser never receives the API token. `netlify/functions/air-alerts.mjs` reads it on the server and exposes only normalized alert data at `/api/air-alerts`.

Before production, issue a new API token because the previous token was shared in a chat. Do not put a token into `index.html`, `app-v6.js`, `netlify.toml`, `_redirects`, a public repository or this ZIP.

In Netlify open:

**Project configuration → Environment variables → Add a variable**

Add:

```text
ALERTS_API_TOKEN = <your newly issued token>
ALERTS_PROVIDER = ukraine-alarm-v3
KYIV_REGION_ID = 31
```

Recommended scope: **Functions**. `KYIV_REGION_ID` is optional because the function can resolve Kyiv from `/api/v3/regions`; keeping it set avoids an extra lookup.

Provider options:

```text
ALERTS_PROVIDER = ukraine-alarm-v3
ALERTS_PROVIDER = alerts-in-ua
ALERTS_PROVIDER = auto
```

`auto` first tries the richer alerts.in.ua v1-compatible feed, then falls back to the Ukraine Alert API v3 endpoints supplied with this project.

After adding or changing environment variables, trigger a new production deploy.

## Deploy to Netlify

1. Unzip the package.
2. Sign in to Netlify.
3. Drag the project folder or ZIP into Netlify Drop, or connect it to a Git repository.
4. Netlify detects `netlify/functions/air-alerts.mjs` and deploys the serverless function.
5. Add the environment variables above and redeploy.
6. Open `/api/air-alerts` on the deployed domain. A successful response contains `"ok": true` and never contains the token.

No npm dependencies or build command are required.

## Data flow

```text
Browser
  ├─ /api/air-alerts       → Netlify Function → configured classified-alert API
  └─ /api/legacy-history   → Netlify proxy    → Kyiv Digital alert history
```

The site merges both feeds by matching alert start times and interval overlap:

- the classified API supplies current alert level, reasons and phases when available;
- Kyiv Digital supplements the longer historical list of start/end timestamps;
- unconfirmed historical classification is never inferred and remains blue-grey;
- durations are recalculated from timestamps;
- ongoing alerts are measured up to the current Kyiv time.

The v3 history endpoint returns completed alert intervals, while live `activeAlertLevels` carries the current red/yellow level and reason. The browser also stores level transitions it has actually observed for up to 21 days. For authoritative cross-device phase history, the next production step is to persist webhook events in a database or Netlify Blobs.

## Timeline rules

- Time zone: `Europe/Kyiv`.
- Geography: Kyiv City, not Kyiv Oblast.
- Daily alert count means alerts that started on that date.
- Intervals crossing midnight are split between calendar days for duration totals.
- `09:00–18:00` means exact overlap with that window.
- Desktop order: oldest to newest, left to right.
- Mobile order: newest to oldest, top to bottom.
- Yellow: drone warning.
- Red: high-level threat.
- Blue-grey: classification unavailable.

## Baseline logic

- The user selects an inclusive range of complete calendar days.
- Days with zero alerts remain in the denominator.
- The site recalculates alerts/day, total alert time/day and `09:00–18:00` alert time/day.
- The selected baseline range is stored locally in the browser.

## Preview mode

For a design preview without live credentials, append:

```text
?demo=classified
```

Demo mode is clearly labelled and uses synthetic data. It must not be used as an operational warning source.

## Files

- `index.html` — semantic page structure
- `styles-v6.css` — responsive visual system
- `app-v6.js` — parsing, merging, analytics, classification UI and interactions
- `netlify/functions/air-alerts.mjs` — secret-safe classified API adapter
- `netlify.toml` / `_redirects` — function and legacy proxy routing
- `_headers` — cache and security headers
